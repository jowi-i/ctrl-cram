/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.motorph;

/**
 *
 * @author miiny
 */
public class MotorPH {

    public static void main(String[] args) {     
}
}
    



